"""A ctypes-based wrapper around the zbar barcode reader."""

__version__ = '0.1.4'
